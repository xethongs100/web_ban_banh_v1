<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//lấy dữ liệu database load lên trang chủ
Route::get('/','PageController@view_home')->name('home');
//chuyển trang tới trang loại sản phẩm theo id
Route::get('home/{name}/{id}','PageController@type_product')->name('type_product');


//dang ki
Route::group(['prefix'=>'register'],function(){
	//chuyển trang tới trang đăng kí
	Route::get('new','RegisterController@view_register')->name('view_register');
	// //xử lý đăng kí
	Route::post('register-new','RegisterController@register')->name('xu_ly_register');
});


//dang nhap
Route::group(['prefix'=>'login'],function(){
	//chuyển tới trang đăng nhập
	Route::get('view','LoginController@view_login')->name('view_login');
	// //xu ly dang nhap
	Route::post('login-xu-ly','LoginController@Login')->name('xu_ly_login');
	// //xu ly logout
	Route::get('logout','LoginController@Logout')->name('logout');
});


//gio hang
Route::group(['prefix'=>'cart'],function(){
	//them san pham
	Route::get('thêm-sản-phẩm/{id}','CartController@addCart')->name('them_san_pham');
	//danh sach gio hang
	Route::get('gio-hang','CartController@show_cart')->name('danh-sach-sp');
	//cap nhat gio hang
	Route::get('gio-hang/cap-nhat/{id}/{qty}','CartController@updateCart');
	//xoa gio hang
	Route::get('xoa-gio-hang/{id}','CartController@delete_cart')->name('xoa-gio-hang');
	//chuyen toi trang dat hang
	Route::get('dat-hang','CartController@view_dat_hang')->name('view-dat-hang');
	//xu ly dat hang
	Route::post('mua-hang','CartController@xu_ly_dat_hang')->name('mua-hang');
	//chuyen toi trang don mua hang
	Route::get('hoa-don','CartController@view_mua_hang')->name('hoa-don');
	//xoa don hang
	Route::get('hoa-don/{id}','CartController@delete_don_hang')->name('delete-don-hang');
});

//trang ca nhan
Route::group(['prefix'=>'profile'],function(){
	Route::get('{id}','ProfileController@view_profile')->name('view_profile');
	Route::post('{id}','ProfileController@change_profile')->name('thay_doi_profile');
	Route::get('change_password/{id}','ProfileController@view_change_password')->name('view_change_pass');
	Route::post('change_password/{id}','ProfileController@xu_ly_change_pass')->name('c_password');
});


Route::group(['prefix'=>'detail'],function(){
	Route::get('san-pham/{id}/{id_type}','PageController@view_chi_tiet_sp')->name('chi_tiet_sp');
	Route::post('comment/{id}/{id_type}/{id_user}','PageController@request_comment')->name('comment');
	Route::get('xoa-comment/{id_comment}/{id_pro}/{id_user}','PageController@xoa_comment')->name('delete-comment');
});


Route::group(['prefix'=>'admin'],function(){
	//san pham
	Route::get('danh-sach-product','QuanLyProductController@view_ds_san_pham')->name('view_ds_product');
	Route::post('danh-sach-product','QuanLyProductController@add_product');
	Route::get('edit/{id}','QuanLyProductController@edit')->name('edit_pro');
	Route::put('update/{id}','StudentController@update');
	Route::get('delete/{id}','StudentController@destroy')->name('delete_pro');

	//comment
	Route::get('danh-sach-comment','QuanLyCommentController@listComment')->name('view_ds_comment');
	Route::get('danh-sach-comment/delete','QuanLyCommentController@listDelComment')->name('view_delete_comment');
	Route::get('danh-sach-comment/store/{id}','QuanLyCommentController@phuc_hoi_comment_delete')->name('phuc_hoi_comment');
});