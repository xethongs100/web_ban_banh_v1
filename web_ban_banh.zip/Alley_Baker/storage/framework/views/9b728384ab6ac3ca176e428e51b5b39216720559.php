<?php $__env->startSection('title'); ?>
	Trang chủ
<?php $__env->stopSection(); ?>

<?php $__env->startSection('slide'); ?>
	<?php echo $__env->make('template.slide', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<?php if(Session::has('thongbao')): ?>
		<script type="text/javascript">
			alert("<?php echo e(Session::get('thongbao')); ?>")
		</script>
	<?php endif; ?>
	<?php echo $__env->make('template.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\Laravel\Alley_Baker\resources\views/index.blade.php ENDPATH**/ ?>