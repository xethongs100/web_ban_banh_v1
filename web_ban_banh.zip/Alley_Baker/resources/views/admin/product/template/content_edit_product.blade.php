<div class="modal fade" id="modal-edit">
	<div class="modal-dialog">
		<div class="modal-content">
				<form action="" id="form-edit" method="POST" role="form" enctype="multipart/form-data">
					@csrf
					<div class="modal-header">
						<h4 class="modal-title">Sửa sản phẩm</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">
						<div class="form-group">
							<label for="">Loại sản phẩm</label>
							<select name="id_type" id="id_type-edit" class="form-control" required="required">
								@foreach($t_product as $ds1)
									<option value="{{$ds1->id}}">{{$ds1->name}}</option>
								@endforeach
							</select>
						</div>
						<div class="form-group">
							<label for="">Tên sản phẩm</label>
							<input name="name" type="text" class="form-control" id="ten_san_pham-edit"  value="" required="required">
						</div>

						<div class="form-group">
							<label for="">Giá tiền</label>
							<input name="price" type="text" class="form-control" id="price-edit" placeholder="Nhập vào giá tiền sản phẩm" value="" required="required">
						</div>


						<div class="form-group">
							<label for="">Hình ảnh cũ</label>
							<br></br>
							<span id="img"></span>
							<br></br>
							<label for="">Hình mới</label>
							<br></br>
							<img src="" style="height:80px;" id="image_edit">
							<input type="file" name="myFile" id="myFile" onchange="show.call(this)" required="required">
						</div>

						<div class="form-group">
							<label for="">Đơn vị</label>
							<input name="unit" type="text" class="form-control" id="unit-edit" placeholder="Nhập vào đơn vị sản phẩm" value="" required="required">
						</div>
					</div>
				
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
						<button type="submit" id="edit_submit" class="btn btn-primary">Sửa</button>
					</div>
				</form>
		</div>
	</div>
</div>
<script type="text/javascript">
		function show() 
		{
			if(this.files && this.files[0])
			{
				var object = new FileReader();
				object.onload = function(data){
					var image = document.getElementById("image_edit");
					image.src = data.target.result;
				}
				object.readAsDataURL(this.files[0]);
			}
		}
</script>