<?php $__env->startSection('title'); ?>
	Chi tiết sản phẩm
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<?php echo $__env->make('chi-tiet-san-pham.template.content_chitietsanpham', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\Laravel\Alley_Baker\resources\views/chi-tiet-san-pham/chi_tiet_product.blade.php ENDPATH**/ ?>