<?php $__env->startSection('table'); ?>
<div class="card-body">
<div class="table-responsive">
  <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
  <br></br>
        <thead>
          <tr>
            <th>Id</th>
            <th>Id_user</th>
            <th>Id_product</th>
            <th>Tên người comment</th>
            <th>Thời gian comment</th>
            <th>Chức năng</th>
          </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $delComment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
           	<td><?php echo e($ds->id); ?></td>
	        <td><?php echo e($ds->id_user); ?></td>
	        <td><?php echo e($ds->id_pro); ?></td>
	        <td><?php echo e($ds->name); ?></td>
	        <td><?php echo e($ds->date); ?></td>
            <td>
              <center><a href="<?php echo e(route('phuc_hoi_comment',['id'=>$ds->id])); ?>" class="btn btn-success">Phục hồi</a></center>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
  </table>
</div>
</div>
<?php $__env->stopSection(); ?>
	

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\Laravel\Alley_Baker\resources\views/admin/comment/ds_comment_delete.blade.php ENDPATH**/ ?>