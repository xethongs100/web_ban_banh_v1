<div class="container">
		<div id="content">
			
			<form action="<?php echo e(route('xu_ly_login')); ?>" method="post">
				<?php echo csrf_field(); ?>
				<input type="hidden" name="_token" id="csrf-token" value="<?php echo e(csrf_token()); ?>"/>
				<div class="row">
					<div class="col-sm-3"></div>
					<div class="col-sm-6">
						<?php if(Session::has('error')): ?>
	                    	<div class="alert alert-danger">
	                    		<?php echo e(Session::get('error')); ?>

	                    	</div>
                    	<?php endif; ?>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-3"></div>
					<div class="col-sm-6">
						<?php if($errors->any()): ?>
							<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                    	<div class="alert alert-danger">
		                    		<ul>
		                    			<li><?php echo e($error); ?></li>
		                    		</ul>
		                    	</div>
	                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    	<?php endif; ?>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-3"></div>
					<div class="col-sm-6">
						<h4>Đăng nhập</h4>
						<div class="space20">&nbsp;</div>
						<div class="form-block">
							<label for="l_email">Email address*</label>
                            <input type="text" id="f_name" name="l_email" class="form-control">
						</div>
						<div class="form-block">
							<label for="l_password">Password*</label>
                            <input type="password" id="f_name" name="l_password" class="form-control">
						</div>
						<div class="form-block">
							<button type="submit" class="btn btn-primary">Login</button>
						</div>
					</div>
					<div class="col-sm-3"></div>
				</div>
			</form>
		</div> <!-- #content -->
	</div> <!-- .container --><?php /**PATH C:\Users\USER\Desktop\Laravel\Alley_Baker\resources\views/template/content_login.blade.php ENDPATH**/ ?>