<br><br>
	<div class="container-fluid">
        <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-8" id="err_msg">
                <?php if(Session::has('change')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('change')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="col-md-2"></div>
        </div>
        <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-8">
                <div class="panel panel-primary">
                    <div class="panel-heading">Change password</div>
                    <div class="panel-body">
                    	<?php if(isset($user)): ?>
                        <form method="post" action="<?php echo e(route('c_password',['id'=>$user->id])); ?>">
                        	<?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <label for="f_name">Mật khẩu cũ*</label>
                                    <input type="password" id="f_name" name="change_pass1" class="form-control">
                                <?php if($errors->has('change_pass1')): ?>
                                    <div class="alert alert-danger">
                                        <?php echo e($errors->first('change_pass1')); ?>

                                    </div>
                                <?php endif; ?>
                                </div>
                                <div class="col-md-6">
                                    <label for="f_name">Mật khẩu mới*</label>
                                    <input type="password" id="l_name" name="change_pass2" class="form-control">
                                <?php if($errors->has('change_pass2')): ?>
                                    <div class="alert alert-danger">
                                        <?php echo e($errors->first('change_pass2')); ?>

                                    </div>
                                <?php endif; ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <label for="mobile">Nhập lại mật khẩu mới*</label>
                                    <input type="password" id="mobile" name="change_pass3" class="form-control">
                                <?php if($errors->has('change_pass3')): ?>
                                    <div class="alert alert-danger">
                                        <?php echo e($errors->first('change_pass3')); ?>

                                    </div>
                                <?php endif; ?>
                                </div>
                                <div class="col-md-6">
                                </div>
                                <div class="col-md-12">
                                    <br>
                                    <input type="submit" class="btn btn-primary" value="Thay đổi" name="change_password" id="signup_btn">
                            </div>
                        </div>
                    </div>
                    </form>
                    <?php endif; ?>
                <div class="panel-footer"></div>
            </div>
        </div>
        <div class="col-md-2"></div>
    </div>
    </div><?php /**PATH C:\Users\USER\Desktop\Laravel\Alley_Baker\resources\views/user/profile/template/content_change_pass.blade.php ENDPATH**/ ?>