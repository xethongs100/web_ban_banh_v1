<div class="container">
		<div id="content">
			<div class="row">
				<div class="col-sm-9">
					<div class="row">
				<?php if(isset($product)&&isset($type_product)): ?>
						<div class="col-sm-4">
							<img src="../../../../image/product/<?php echo e($product->image); ?>" alt="">
						</div>
						<div class="col-sm-8">
						
							<div class="single-item-body">
								<p class="single-item-title"><?php echo e($product->name); ?></p>
								<p class="single-item-price">
									<span>Giá tiền:<?php echo e($product->promotion_price); ?>VNĐ</span>
								</p>
							</div>
							<div class="clearfix"></div>
							<div class="space20">&nbsp;</div>

							<div class="single-item-desc">
							</div>
							<div class="space20">&nbsp;</div>
							<div class="single-item-options">
							</div>
						</div>
					</div>

					<div class="space40">&nbsp;</div>
				<div class="woocommerce-tabs">
						<ul class="tabs">
							<li><a href="#tab-description">Description</a></li>
						<?php if(isset($count)): ?>
							<li><a href="#tab-reviews">Reviews (<?php echo e($count); ?>)</a></li>
						<?php else: ?>
							<li><a href="#tab-reviews">Reviews (0)</a></li>
						<?php endif; ?>
						</ul>
						<div class="panel" id="tab-description">
							<p><?php echo e($type_product->description); ?></p>
						</div>
					
					<div class="panel" id="tab-reviews">
						<p>
					<?php if(Auth::check()): ?>
						<form method="post" action="<?php echo e(route('comment',['id'=>$product->id,'id_type'=>$product->id_type,'id_user'=>Session::get('id')])); ?>">
						<?php echo csrf_field(); ?>
								<div class="form-block">
									<label for="notes">Ghi bình luận</label>
									<textarea name="comment" id="notes" class="form-control"></textarea>
								</div>

								<div class="form-block">
									<input type="submit" name="" class="beta-btn primary" style="width:150px;" value="Gửi bình luận">
								</div>
						</form>
					<?php endif; ?>
						</p>
					<hr width="100%">
					<?php $__currentLoopData = $comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<h6><b><?php echo e($cm->name); ?></b></h6>
						<p>Bình luận:<?php echo e($cm->comment); ?></p>
						<p><?php echo e($cm->date); ?></p>
						<a href="#tab-description">Trả lời</a>&nbsp;&nbsp;&nbsp;&nbsp;
					<?php if(Auth::check()): ?>
						<a href="<?php echo e(route('delete-comment',['id_comment'=>$cm->id,'id_pro'=>$cm->id_pro,'id_user'=>Session::get('id')])); ?>">Xóa</a> 
					<?php endif; ?>
						<br><hr width="100%">
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>

					<div class="space50">&nbsp;</div>
					<div class="beta-products-list">
					</div> <!-- .beta-products-list -->
				</div>
				<div class="col-sm-3 aside">
					<div class="widget">
						<h3 class="widget-title">Quảng cáo</h3>
						<div class="widget-body">
							<div class="beta-sales beta-lists">
								<div class="media beta-sales-item">
									<a class="pull-left" href="product.html"><img src="assets/dest/images/products/sales/1.png" alt=""></a>
									<div class="media-body">
										Sample Woman Top
										<span class="beta-sales-price">$34.55</span>
									</div>
								</div>
							</div>
						</div>
				<?php endif; ?>
					</div> <!-- best sellers widget -->
				</div>
			</div>
		</div> <!-- #content -->
	</div> <!-- .container --><?php /**PATH C:\Users\USER\Desktop\Laravel\Alley_Baker\resources\views/chi-tiet-san-pham/template/content_chitietsanpham.blade.php ENDPATH**/ ?>