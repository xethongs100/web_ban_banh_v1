@extends('layout')
@section('title')
	Đăng nhập
@endsection
@section('content')
	@include('template.content_login')
@endsection