<div class="card shadow mb-4">
  <div class="card-body">
    <div class="table-responsive">
      <?php if(Session::has('thongbao')): ?>
          <div class="alert alert-success">
            <?php echo e(Session::get('thongbao')); ?>

          </div>
      <?php endif; ?>
      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
      <a href="" data-target="#modal-add" data-toggle="modal" class="btn btn-success btn-add">Thêm mới</a>
      <br></br>
            <thead>
              <tr>
                <th>Id</th>
                <th>Id_type</th>
                <th>Tên sản phẩm</th>
                <th>Description</th>
                <th>Giá gốc</th>
                <th>Giá khuyến mãi</th>
                <th>Hình ảnh</th>
                <th>Đơn vị</th>
                <th>Chức năng</th>
              </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($ds->id); ?></td>
                <td><?php echo e($ds->id_type); ?></td>
                <td><?php echo e($ds->name); ?></td>
                <td><?php echo e($ds->description); ?></td>
                <td><?php echo e($ds->unit_price); ?></td>
                <td><?php echo e($ds->promotion_price); ?></td>
                <td><img src="../image/product/<?php echo e($ds->image); ?>" style="height:80px;width:80px;"></td>
                <td><?php echo e($ds->unit); ?></td>
                <td>
                  <button data-url="<?php echo e(route('edit_pro',['id'=>$ds->id])); ?>"​ type="button" data-target="#modal-edit" data-toggle="modal" class="btn btn-warning btn-edit">Sửa</button>
                  <br></br>
                  <button data-url="<?php echo e(route('delete_pro',['id'=>$ds->id])); ?>"​ type="button" data-target="#delete" data-toggle="modal" class="btn btn-danger btn-delete">Xóa</button>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
      </table>
    </div>
  </div>
</div>
<?php /**PATH C:\Users\USER\Desktop\Laravel\Alley_Baker\resources\views/admin/product/template/content_ds_product.blade.php ENDPATH**/ ?>