@extends('layout')
@section('title')
	Thay đổi mật khẩu
@endsection
@section('content')
	@include('user.profile.template.content_change_pass')
@endsection