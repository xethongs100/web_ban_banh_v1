@extends('admin.layout')
@section('title')
	Trang quản lý sản phẩm
@endsection
@section('ten_quan_ly')
	Quản lý sản phẩm
@endsection
@section('table')
	@include('admin.product.template.content_ds_product')
@endsection

