<div class="container">
		<div id="content" class="space-top-none">
			<div class="main-content">
				<div class="space60">&nbsp;</div>
				<div class="row">
					<div class="col-sm-12">
						<div class="beta-products-list">
							<h4>New Products</h4>
							<div class="beta-products-details">
								<p class="pull-left">438 styles found</p>
								<div class="clearfix"></div>
							</div>
							<div class="row">
							<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<form method="GET" action="<?php echo e(route('them_san_pham',['id'=>$ds->id])); ?>">
								<div class="col-sm-3">
									<div class="single-item">
										<div class="ribbon-wrapper"><div class="ribbon sale">Sale</div></div>
										<div class="single-item-header">
											<a href="<?php echo e(route('chi_tiet_sp',['id'=>$ds->id,'id_type'=>$ds->id_type])); ?>"><img src="image/product/<?php echo e($ds->image); ?>" style="height:250px;" alt=""></a>
										</div>
										<div class="single-item-body">
											<p class="single-item-title"><?php echo e($ds->name); ?></p>
											<p class="single-item-price">
												<span class="flash-del">$<?php echo e($ds->unit_price); ?></span>
												<span class="flash-sale">$<?php echo e($ds->promotion_price); ?></span>
											</p>
										</div>
										<div class="single-item-caption">
											<input type="submit" name="" class="btn btn-success btn-xs" value="ADD">
											<a class="beta-btn primary" href="">Details <i class="fa fa-chevron-right"></i></a>
											<div class="clearfix"></div>
										</div>
									</div>
									<br>
								</div>
							</form>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
							<span"><?php echo e($product->links()); ?></span>
						</div> <!-- .beta-products-list -->
					</div>
				</div> <!-- end section with sidebar and main content -->
			</div> <!-- .main-content -->
		</div> <!-- #content -->
</div> <!-- .container --><?php /**PATH C:\Users\USER\Desktop\Laravel\Alley_Baker\resources\views/template/content.blade.php ENDPATH**/ ?>