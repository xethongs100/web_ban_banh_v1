<div class="modal fade" id="modal-add">
	<div class="modal-dialog">
		<div class="modal-content">
			<form action="" method="POST" data-url="{{ asset('danh-sach-product') }}" id="form-add"  role="form" enctype="multipart/form-data">
				@csrf
				<div class="modal-header">
					<h4 class="modal-title">Thêm sản phẩm</h4>
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				</div>
				<div class="modal-body">
					<div class="form-group">
						<label for="">Loại sản phẩm</label>
						<select name="id_type" id="id_type" class="form-control" required="required">
						@foreach($t_product as $ds1)
							<option value="{{$ds1->id}}">{{$ds1->name}}</option>
						@endforeach
						</select>
					</div>

					<div class="form-group">
						<label for="">Tên sản phẩm</label>
						<input name="ten_san_pham" type="text" class="form-control" id="ten_san_pham" placeholder="Nhập vào tên sản phẩm" required="required">
					</div>

					<div class="form-group">
						<label for="">Giá tiền</label>
						<input name="price" type="text" class="form-control" id="price" placeholder="Nhập vào giá tiền sản phẩm" required="required">
					</div>

					<div class="form-group">
						<input type="file" name="myFile" id="myFile" onchange="showImage.call(this)" required="required">
						<br></br>
						<label for="">Hình ảnh</label>
						<img src="" style="height:100px;" id="image">
					</div>

					<div class="form-group">
						<label for="">Đơn vị</label>
						<input name="unit" type="text" class="form-control" id="unit" placeholder="Nhập vào đơn vị sản phẩm" required="required">
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<button type="submit" class="btn btn-primary">Thêm</button>
				</div>
			</form>
		</div>
	</div>
</div>
<script type="text/javascript">
		function showImage() 
		{
			if(this.files && this.files[0])
			{
				var object = new FileReader();
				object.onload = function(data){
					var image = document.getElementById("image");
					image.src = data.target.result;
				}
				object.readAsDataURL(this.files[0]);
			}
		}
</script>
