<div class="container">
		<div id="content">
			
			<div class="table-responsive">
				<!-- Shop Products Table -->
				<table class="shop_table beta-shopping-cart-table" cellspacing="0">
					<thead>
						<tr>
							<th class="product-name">Sản phẩm</th>
							<th class="product-price">Giá tiền</th>
							<th class="product-status">Trạng thái</th>
							<th class="product-quantity">Số lượng</th>
							<th class="product-subtotal">Tổng tiền</th>
							<th class="product-remove">Thao tác</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $listCart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr class="cart_item">
							<td class="product-name">
								<div class="media">
									<img class="pull-left" src="image/product/<?php echo e($ds->options->img); ?>" style="width:80px;height:60px;" alt="">
									<div class="media-body">
										<p class="font-large table-title">Đơn vị: hộp</p>
										<p class="font-large table-title"></p>
										<p class="font-large table-title"><?php echo e($ds->name); ?></p>
									</div>
								</div>
							</td>

							<td class="product-price">
								<span class="amount"><?php echo e($ds->price); ?>đ</span>
							</td>

							<td class="product-status">
								Còn hàng
							</td>

							<td class="product-quantity">
								<input type="number" name="quantity" min="1" max="100" value="<?php echo e($ds->qty); ?>">
							</td>

							<td class="product-subtotal">
								<span class="amount"><?php echo e($ds->qty*$ds->price); ?>đ</span>
							</td>

							<td class="product-remove">
								<a href="" class="update" id=""><p class="btn btn-success"><span class="glyphicon glyphicon-refresh"></span></p></a>
								<a href="" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span></a>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>

					<tfoot>
						<tr>
							<td colspan="6" class="actions">
								<button type="submit" class="beta-btn primary" name="proceed">Đặt hàng<i class="fa fa-chevron-right"></i></button>
							</td>
						</tr>
					</tfoot>
				</table>
				<!-- End of Shop Table Products -->
			</div>


			<!-- Cart Collaterals -->
			
			<!-- End of Cart Collaterals -->
			<div class="clearfix"></div>

		</div> <!-- #content -->
	</div> <!-- .container --><?php /**PATH C:\Users\USER\Desktop\Laravel\Alley_Baker\resources\views/cart/content_cart.blade.php ENDPATH**/ ?>