@extends('layout')
@section('title')
	Giỏ hàng
@endsection
@section('content')
	@include('gio-hang.content_cart')
@endsection