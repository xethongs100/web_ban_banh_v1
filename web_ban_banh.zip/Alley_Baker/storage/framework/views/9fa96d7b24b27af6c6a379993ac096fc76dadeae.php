<?php $__env->startSection('title'); ?>
	Đơn mua
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<?php echo $__env->make('gio-hang.content_muahang', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\Laravel\Alley_Baker\resources\views/gio-hang/mua-hang.blade.php ENDPATH**/ ?>