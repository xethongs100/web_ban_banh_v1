<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\TypeProduct;
class LoginController extends Controller
{
    //

    public function view_login()
    {
        $t_product = TypeProduct::all();
        return view('login',compact('t_product'));
    }

    public function Login(Request $rq)
    {
    	//kiem tra nguoi dung nhap chua
    	$this->validate($rq,
			[
				'l_email'=>'required|email',
				'l_password'=>'required'
			],

			[
				'l_email.required'=>'Email không được để trống',
				'l_email.email'=>'email không đúng định dạng',
				'l_password.required'=>'Password không được để trống'
			]
    	);

    	if(Auth::attempt(['email'=>$rq->l_email,'password'=>$rq->l_password]))
    	{
    		if(Auth::User()->role==2){
                $rq->session()->put('name',Auth::User()->email);
                $rq->session()->put('id',Auth::User()->id);
    			return view('admin.layout');
    		}

    		else{
    			//lưu email và id người dùng bằng session
	            $rq->session()->put('name',Auth::User()->email);
	            $rq->session()->put('id',Auth::User()->id);
	            //chuyển trang về trang chủ
	            return redirect('/');
    		}
    	}
    	else{
            return redirect()->back()->with('error','Email hoặc mật khẩu sai');
        }
    }

    public function Logout(request $rq)
    {
    	$rq->session()->flush();
        Auth::logout();
        return redirect('/');
    }
}
