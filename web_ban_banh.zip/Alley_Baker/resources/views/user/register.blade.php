@extends('layout')
@section('title')
	Register
@endsection
@section('content')
	@include('user.content_register')
@endsection