<div class="container">
		<div id="content">
			
			<form action="<?php echo e(route('xu_ly_register')); ?>" method="post" class="">
				<?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-sm-3"></div>
                    <div class="col-sm-6">
                        <?php if(Session::has('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(Session::get('success')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-sm-3"></div>
                </div>
				<div class="row">
					<div class="col-sm-3"></div>
					<div class="col-sm-6">
						<?php if($errors->any()): ?>
							<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                    	<div class="alert alert-danger">
		                    		<ul>
		                    			<li><?php echo e($error); ?></li>
		                    		</ul>
		                    	</div>
	                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    	<?php endif; ?>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-3"></div>
					<div class="col-sm-6">
						<h4>Đăng kí</h4>
						<div class="space20">&nbsp;</div>
						<div class="form-block">
                            <label for="email">Email address*</label>
                            <input type="text" id="f_name" name="email" class="form-control">
						</div>

						<div class="form-block">
                            <label for="f_name">Fullname*</label>
                            <input type="text" id="f_name" name="full_name" class="form-control">
						</div>

                        <div class="form-block">
                              <label for="password">Password*</label>
                            <input type="password" id="f_name" name="password" class="form-control">
                        </div>

                        <div class="form-block">
                            <label for="re_password">Re-password*</label>
                            <input type="password" id="f_name" name="re_password" class="form-control">
                        </div>

						<div class="form-block">
                            <label for="address">Address*</label>
                            <input type="text" id="f_name" name="address" class="form-control">
						</div>

						<div class="form-block">
                              <label for="phone">Phone*</label>
                            <input type="text" id="f_name" name="phone" class="form-control">
						</div>
						
						<div class="form-block">
							<button type="submit" class="btn btn-primary">Register</button>
						</div>
					</div>
					<div class="col-sm-3"></div>
				</div>
			</form>
		</div> <!-- #content -->
	</div> <!-- .container --><?php /**PATH C:\Users\USER\Desktop\Laravel\Alley_Baker\resources\views/user/content_register.blade.php ENDPATH**/ ?>