<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use App\TypeProduct;
class QuanLyProductController extends Controller
{
    //
    public function view_ds_san_pham()
    {
    	$product = Product::all();
    	$t_product = TypeProduct::all();
    	return view('admin.product.ds_product',compact('product','t_product'));
    }

    public function add_product(Request $rq)
    {
    	// $validation = $this->validate($rq,[
    	// 	[
    	// 		'id_type'=>'required',
    	// 		'ten_san_pham'=>'required',
    	// 		'price'=>'required',
    	// 		'myFile'=>'image|required|mimes:jpeg,png,jpg,gif|max:2048',
    	// 		'unit'=>'required',
    	// 	],
    	// 	[
    	// 		'id_type.required'=>'Loại sản phẩm không được để trống',
    	// 		'ten_san_pham.required'=>'Loại sản phẩm không được để trống',
    	// 		'id_type.required'=>'Loại sản phẩm không được để trống',
    	// 		'file.required'=>'Loại sản phẩm không được để trống',
    	// 		'file.image'=>'Không đúng định dạng',
    	// 		'file.mimes'=>'Không đúng loại ảnh jpeg,png,jpg,gif,svg',
    	// 		'file.max'=>'Kích thước ảnh quá lớn',
    	// 		'unit.required'=>'Loại sản phẩm không được để trống',
    	// 	]
    	// ]);

        if($rq->hasFile('myFile'))
        {
            $image = $rq->file('myFile');
            $namefile = $image->getClientOriginalName();
            $image->move('image\product',$namefile);

            $product = new Product();
            $product->id_type = $rq->id_type;
            $product->name = $rq->ten_san_pham;
            $product->description = "";
            $product->unit_price = 0;
            $product->promotion_price = $rq->price;
            $product->image = $namefile;
            $product->unit = $rq->unit;

            $product->save();
            return back()->with('thongbao','Thêm sản phẩm thành công');
        }
    }


    public function edit(Request $rq)
    {
        $product = Product::find($rq->id);
        return response()->json(['data'=>$product],200);
    }

    public function update(Request $rq,$id)
    {
        $product = Product::find($id);
        if($rq->hasFile('myFile'))
        {
            $file = $rq->file('myFile');
            $namefile = $file->getClientOriginalName();
            $file->move('assets\prod_images',$namefile);

            $product->id_type = $rq->id_type;
            $product->name = $rq->name;
            $product->promotion_price = $rq->price;
            $product->image = $namefile;
            $product->unit = $rq->unit;

            $product->save();
            return redirect("admin/danh-sach-product");
            //dd($namefile);
        }
    }

    public function delete($id)
    {
    	$product = Product::find($id);
    	$product->delete();
    	return redirect("admin/danh-sach-product");
    }
}
