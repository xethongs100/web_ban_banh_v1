<?php $__env->startSection('title'); ?>
	Thay đổi mật khẩu
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<?php echo $__env->make('user.profile.template.content_change_pass', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\Laravel\Alley_Baker\resources\views/user/profile/profile_change_password.blade.php ENDPATH**/ ?>