@extends('layout')
@section('title')
	Đơn mua
@endsection
@section('content')
	@include('gio-hang.content_muahang')
@endsection