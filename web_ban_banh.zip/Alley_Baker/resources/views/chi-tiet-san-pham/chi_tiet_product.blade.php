@extends('layout')
@section('title')
	Chi tiết sản phẩm
@endsection
@section('content')
	@include('chi-tiet-san-pham.template.content_chitietsanpham')
@endsection