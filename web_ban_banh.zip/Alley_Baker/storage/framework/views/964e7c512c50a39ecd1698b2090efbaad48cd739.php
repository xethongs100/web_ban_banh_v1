<div class="container">
		<br>
		<?php if(isset($customer)): ?>
			<h5 class="btn btn-danger">Địa chỉ giao hàng:(+084)<?php echo e($customer->phone_number); ?>&nbsp-<?php echo e($customer->name); ?>&nbsp-<?php echo e($customer->address); ?></h5>
		<?php endif; ?>
		<div id="content">
			<div class="table-responsive">
				<!-- Shop Products Table -->
				<table class="shop_table beta-shopping-cart-table" cellspacing="0">
					<thead>
						<tr>
							<th class="product-name">Sản phẩm</th>
							<th class="product-price">Giá tiền</th>
							<th class="product-status">Ghi chú</th>
							<th class="product-quantity">Số lượng</th>
							<th class="product-subtotal">Tổng tiền</th>
							<th class="product-remove">Thao tác</th>
						</tr>
					</thead>
					<tbody>
					<?php $__currentLoopData = $bill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr class="cart_item">
							<td >
								<div class="media">
									<img class="pull-left" src="../image/product/<?php echo e($ds->img); ?>" style="width:80px;height:60px;" alt="">
									<div class="media-body">
										<p class="font-large table-title"><?php echo e($ds->name); ?></p>
										<p class="cart-item-options">Đơn vị:<?php echo e($ds->unit); ?></p>
									</div>
								</div>
							</td>

							<td >
								<span class="amount"><?php echo e($ds->price); ?></span>
							</td>

							<td >
								<?php echo e($ds->note); ?>

							</td>

							<td>
								<?php echo e($ds->qty); ?>

							</td>

							<td>
								<span class="amount"><?php echo e($ds->total); ?></span>
							</td>
							<td>
								<a href="<?php echo e(route('delete-don-hang',['id'=>$ds->id])); ?>"><p class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span></p></a>
							</td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
				<!-- End of Shop Table Products -->
			</div>
			<!-- Cart Collaterals -->
			<!-- End of Cart Collaterals -->
			<div class="clearfix"></div>
		</div> <!-- #content -->
</div> <!-- .container --><?php /**PATH C:\Users\USER\Desktop\Laravel\Alley_Baker\resources\views/gio-hang/content_muahang.blade.php ENDPATH**/ ?>