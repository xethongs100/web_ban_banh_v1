@extends('layout')
@section('title')
	Loại bánh
@endsection
@section('content')
	@include('product_type.content_type_product')
@endsection