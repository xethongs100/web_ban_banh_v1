<?php $__env->startSection('title'); ?>
	Trang quản lý sản phẩm
<?php $__env->stopSection(); ?>
<?php $__env->startSection('ten_quan_ly'); ?>
	Quản lý sản phẩm
<?php $__env->stopSection(); ?>
<?php $__env->startSection('table'); ?>
	<?php echo $__env->make('admin.product.template.content_ds_product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\Laravel\Alley_Baker\resources\views/admin/product/ds_product.blade.php ENDPATH**/ ?>