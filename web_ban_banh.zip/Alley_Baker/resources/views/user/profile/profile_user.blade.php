@extends('layout')
@section('title')
	Profile
@endsection
@section('content')
	@include('user.profile.template.content_profile')
@endsection