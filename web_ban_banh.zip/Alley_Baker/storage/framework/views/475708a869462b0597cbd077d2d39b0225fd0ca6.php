<div class="container">
	
		<div id="content">
			<div class="table-responsive">
			
				<!-- Shop Products Table -->
				<table class="shop_table beta-shopping-cart-table" cellspacing="0">
					<thead>
						<tr>
							<th class="product-name">Sản phẩm</th>
							<th class="product-price">Giá tiền</th>
							<th class="product-status">Trạng thái</th>
							<th class="product-quantity">Số lượng</th>
							<th class="product-subtotal">Tổng tiền</th>
							<th class="product-remove">Thao tác</th>
						</tr>
					</thead>
					<tbody>
					<form method="POST" action="">
						<input type="hidden" name="_token" id="csrf-token" value="<?php echo e(csrf_token()); ?>"/>
						<?php $__currentLoopData = $listCart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr class="cart_item">
							<td >
								<div class="media">
									<img class="pull-left" src="../image/product/<?php echo e($ds->options->img); ?>" style="width:80px;height:60px;" alt="">
									<div class="media-body">
										<p class="font-large table-title"><?php echo e($ds->name); ?></p>
										<p class="cart-item-options">Đơn vị:<?php echo e($ds->options->unit); ?></p>
									</div>
								</div>
							</td>

							<td >
								<span class="amount"><?php echo e($ds->price); ?>đ</span>
							</td>

							<td >
								Còn hàng
							</td>

							<td >
								<input type="number" name="qty" min="1" max="100" value="<?php echo e($ds->qty); ?>">
							</td>

							<td>
								<span class="amount"><?php echo e($ds->qty*$ds->price); ?>đ</span>
							</td>

							<th>
								<a href="" class="update" id="<?php echo e($ds->rowId); ?>"><p class="btn btn-success"><span class="glyphicon glyphicon-refresh"></span></p></a>

								<a href="<?php echo e(route('xoa-gio-hang',['id'=>$ds->rowId])); ?>"><p class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span></p></a>
							</th>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</form>
					</tbody>

					<tfoot>
						<tr>
							<td colspan="6" class="actions">
								<a href="<?php echo e(route('view-dat-hang')); ?>" class="beta-btn primary" name="proceed">Đặt hàng<i class="fa fa-chevron-right"></i></a>
							</td>
						</tr>
					</tfoot>
				</table>
				<!-- End of Shop Table Products -->
			
			</div>
			<!-- Cart Collaterals -->
			<!-- End of Cart Collaterals -->
			<div class="clearfix"></div>

		</div> <!-- #content -->
		
	</div> <!-- .container --><?php /**PATH C:\Users\USER\Desktop\Laravel\Alley_Baker\resources\views/gio-hang/content_cart.blade.php ENDPATH**/ ?>