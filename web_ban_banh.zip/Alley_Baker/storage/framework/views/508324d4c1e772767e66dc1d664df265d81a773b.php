<?php $__env->startSection('name_quanly'); ?>
	Quản lý comment người dùng
<?php $__env->stopSection(); ?>
<?php $__env->startSection('table'); ?>
<div class="card shadow mb-4">
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
      <a href="<?php echo e(route('view_delete_comment')); ?>" class="btn btn-success btn-edit">Xem lại comment đã xóa</a>
      <br></br>
            <thead>
              <tr>
                <th>Id</th>
                <th>Id_user</th>
                <th>Id_product</th>
                <th>Tên người comment</th>
                <th>Thời gian comment</th>
                <th>Chức năng</th>
              </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($ds->id); ?></td>
                <td><?php echo e($ds->id_user); ?></td>
                <td><?php echo e($ds->id_pro); ?></td>
                <td><?php echo e($ds->name); ?></td>
                <td><?php echo e($ds->date); ?></td>
                <td>
                  <center><a href="" class="btn btn-success">Xác nhận</a></center>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\Laravel\Alley_Baker\resources\views/admin/comment/ds_comment.blade.php ENDPATH**/ ?>