@extends('layout')
@section('title')
	Đặt hàng
@endsection
@section('content')
	@include('gio-hang.content_giohang')
@endsection